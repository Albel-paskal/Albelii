<?php
$host = 'localhost';
$dbname = 'mysystem';
$username = 'root';
$password = '';


try {
    $mysqli = new mysqli($host, $username, $password, $dbname);
    if ($mysqli->connect_error) {
        die('Connection failed: ' . $mysqli->connect_error);
    }
} catch (Exception $e) {
    die('Connection failed: ' . $e->getMessage());
}
?>
