<?php
require 'connect.php';
session_start();

// CSRF token generation & expiration (30 min)
if (empty($_SESSION['csrf_token']) || ($_SESSION['token_time'] ?? 0) < time() - 1800) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['token_time'] = time();
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors[] = 'Invalid or expired CSRF token.';
    }

    $email = trim($_POST['email'] ?? '');
    if (!$email) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address';
    }

    if (empty($errors)) {
        try {
            // Duplicate check
            $stmt = $mysqli->prepare('SELECT id FROM subscriber WHERE email = ?');
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $errors[] = 'This email is already subscribed';
            } else {
                $stmt->close();

                // Insert new subscriber
                $ins = $mysqli->prepare('INSERT INTO subscriber (email) VALUES (?)');
                $ins->bind_param('s', $email);
                $ins->execute();
                $success = true;

                unset($_SESSION['csrf_token'], $_SESSION['token_time']);

                // Redirect to index.php
                header('Location: index.php');
                exit;
            }
            $stmt->close();

        } catch (\mysqli_sql_exception $e) {
            error_log('DB Query Error: ' . $e->getMessage());
            $errors[] = 'Sorry, a system error occurred. Please try again later.';
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Albel Graphics & Web Design</title>
    <style>
        body { font:15px/1.5 Arial,sans-serif; margin:0; padding:0; }
        .container { width:80%; margin:auto; overflow:hidden; }
        header, footer, #newsletter { background:#35424a; color:#fff; }
        header { padding:30px 0; border-bottom:3px solid #e8491d; }
        header a { color:#fff; text-decoration:none; text-transform:uppercase; }
        nav ul { list-style:none; margin:0; padding:0; }
        nav li { display:inline; padding:0 20px; }
        .highlight, .current a { color:#e8491d; font-weight:bold; }
        .button_1 { background:#e8491d; color:#fff; border:none; padding:10px 20px; cursor:pointer; }
        #newsletter { padding:15px 0; }
        #boxes { margin:20px 0; }
        .box { float:left; width:30%; text-align:center; padding:10px; box-sizing:border-box; }
        .box img { width:100%; height:auto; }
        footer { text-align:center; padding:20px 0; background:#e8491d; color:#fff; clear:both; }
        .errors p, .success { padding:10px; margin:5px 0; }
        .errors p { background:#fdd; color:#900; }
        .success { background:#dfd; color:#060; }
        @media(max-width:768px){
            nav, #newsletter form, .box { width:100%; display:block; text-align:center; }
        }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1><span class="highlight">Albel</span> Graphics & Web Design</h1>
        <nav>
            <ul>
                <li class="current"><a href="#">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li>
            </ul>
        </nav>
    </div>
</header>

<section id="newsletter">
    <div class="container">
        <h1>Subscribe To The Website</h1>
        <?php if ($errors): ?>
            <div class="errors">
                <?php foreach ($errors as $e): ?>
                    <p><?=htmlspecialchars($e)?></p>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <p class="success">Thank you for subscribing!</p>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
            <input type="email" name="email" placeholder="Enter Email..." required>
            <button type="submit" name="subscriber" class="button_1">Subscribe</button>
        </form>
    </div>
</section>

<section id="boxes">
    <div class="container">
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Website+Design" alt="Website Design">
            <h3>Website Design</h3>
        </div>
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Website+Development" alt="Website Development">
            <h3>Website Development</h3>
        </div>
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Website+Maintenance" alt="Website Maintenance">
            <h3>Website Maintenance</h3>
        </div>
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Website+Hosting" alt="Website Hosting">
            <h3>Website Hosting</h3>
        </div>
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Database+Creation" alt="Database Creation">
            <h3>Database Creation</h3>
        </div>
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Graphic+Design" alt="Graphic Design">
            <h3>Graphic Design</h3>
        </div>
        <div class="box">
            <img src="https://via.placeholder.com/400x250.png?text=Networking+Services" alt="Networking Services">
            <h3>Networking Services</h3>
        </div>
    </div>
</section>


<footer>
    <p>&copy; 2025 Albel Computer Graphics and Web Design</p>
</footer>

</body>
</html>

