-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2025 at 06:04 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mysystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `phone`, `message`, `submitted_at`) VALUES
(1, 'albel', '0782689267', 'ahaha', '2025-06-17 04:39:24'),
(2, 'albel', '0782689267', 'hi', '2025-06-17 04:40:06'),
(3, 'albel', '0782637267', 'hey', '2025-06-17 04:46:02'),
(4, 'moses', '0782634267', 'umekula', '2025-06-17 04:48:19'),
(5, 'moses', '0782689267', 'jj', '2025-06-17 04:53:00'),
(6, 'albel', '0782634267', 'hi', '2025-06-17 04:53:32'),
(7, 'albel', '0782634267', 'hi', '2025-06-17 04:58:34'),
(8, 'irene', '0782634290', 'hi', '2025-06-17 04:58:58'),
(9, 'irene', '0782634290', 'hi', '2025-06-17 04:59:03'),
(10, 'albel', '0782689267', 'hh', '2025-06-17 04:59:59'),
(11, 'albel', '0782689267', 'hh', '2025-06-17 05:00:04'),
(12, 'albel', '0782689267', 'hh', '2025-06-17 05:01:08'),
(13, 'albel', '0782689267', 'hh', '2025-06-17 05:05:52'),
(14, 'moses', '0782634267', 'have it', '2025-06-17 05:06:04');

-- --------------------------------------------------------

--
-- Table structure for table `subscriber`
--

CREATE TABLE `subscriber` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subscribed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active',
  `verified` tinyint(1) DEFAULT 0,
  `unsubscribed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscriber`
--

INSERT INTO `subscriber` (`id`, `email`, `subscribed_at`, `status`, `verified`, `unsubscribed_at`) VALUES
(1, 'albelpaskal1@gmail.com', '2025-06-17 03:59:44', 'active', 0, NULL),
(2, 'msokote@gmail.com', '2025-06-17 04:00:36', 'active', 0, NULL),
(3, 'allyy@gmail.com', '2025-06-17 04:08:39', 'active', 0, NULL),
(4, 'noelmayali1@gmail.com', '2025-06-17 04:16:42', 'active', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscriber`
--
ALTER TABLE `subscriber`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `subscriber`
--
ALTER TABLE `subscriber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
