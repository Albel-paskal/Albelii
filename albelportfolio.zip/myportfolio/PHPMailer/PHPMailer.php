<?php
namespace PHPMailer\PHPMailer;

class PHPMailer {
    const ENCRYPTION_STARTTLS = 'tls';
    const ENCRYPTION_SMTPS = 'ssl';

    public function isSMTP() {}
    public $Host;
    public $SMTPAuth;
    public $Username;
    public $Password;
    public $SMTPSecure;
    public $Port;
    public function setFrom($address, $name = '') {}
    public function addAddress($address, $name = '') {}
    public function isHTML($isHtml = true) {}
    public $Subject;
    public $Body;
    public function send() { return true; }
    public $ErrorInfo;
}
?>

