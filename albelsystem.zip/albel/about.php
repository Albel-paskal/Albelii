<?php
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Albel Graphics & Web Design</title>
    <style>
        body { font:15px/1.5 Arial,sans-serif; margin:0; padding:0; }
        .container { width:80%; margin:auto; overflow:hidden; }
        header, footer, #newsletter { background:#35424a; color:#fff; }
        header { padding:30px 0; border-bottom:3px solid #e8491d; }
        header a { color:#fff; text-decoration:none; text-transform:uppercase; }
        nav ul { list-style:none; margin:0; padding:0; }
        nav li { display:inline; padding:0 20px; }
        .highlight, .current a { color:#e8491d; font-weight:bold; }
        .button_1 { background:#e8491d; color:#fff; border:none; padding:10px 20px; cursor:pointer; }
        #newsletter { padding:15px 0; }
        footer { text-align:center; padding:20px 0; background:#e8491d; color:#fff; clear:both; }
        .errors p, .success { padding:10px; margin:5px 0; }
        .errors p { background:#fdd; color:#900; }
        .success { background:#dfd; color:#060; }
        #boxes { margin:20px 0; }
        .box { float:left; width:30%; text-align:center; padding:10px; box-sizing:border-box; }
        .box img { width:100%; height:auto; }
        article#main-col { float:left; width:65%; margin-bottom: 20px; }
        aside#sidebar { float:right; width:30%; margin-top:40px; padding:4px; }
        ul#services li { list-style: none; padding:20px; border: #ccc solid 1px; background:#e6e6e6; margin-bottom:5px; }
        .dark { padding:4px; background:#35424a; color:#fff; margin-top:1px; margin-bottom:10px; width:100%; box-sizing: border-box; }

        @media(max-width:768px){
            nav, #newsletter form, .box, article#main-col, aside#sidebar {
                width:100%; display:block; float:none;
            }
            #newsletter button, .quote button {
                width:100%;
            }
            #newsletter input[type="email"] {
                width:90%;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="container">
        <div id="branding">
            <h1><span class="highlight">Albel</span> Graphics & Web Design</h1>
        </div>
        <nav>
            <ul>
                <li class="current"><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li>
            </ul>
        </nav>
    </div>
</header>

<section id="main">
    <div class="container">
        <article id="main-col">
            <h1 class="page-title">About Us</h1>
            <p>Nation - Tanzania</p>
            <p>City - Arusha</p>
            <p>Location - Arusha Town, Arusha</p>
        </article>

        <article id="main-col">
            <h1 class="page-title">Contact Us</h1>
            <p>Email: <b>albelpaskal1@gmail.com</b></p>
            <p>WhatsApp: <b>+255 789 936 077</b></p>
            <p>Instagram: <b>albelgraphics</b></p>
        </article>

        <article id="main-col">
            <h1 class="page-title">What We Do</h1>
            <p>We design websites for organizations, companies, and businesses (public and private), including e-commerce platforms with delivery systems.</p>
            <p>We create graphic designs like logos, posters, flyers, brochures, and photo editing.</p>
            <p>We develop databases to store organizational or company information efficiently.</p>
        </article>

        <aside id="sidebar">
            <div class="dark">
                <h3>Subscribe for More Information</h3>
                <p>Stay up to date with the latest from Albel Graphics & Web Design.</p>
            </div>
        </aside>
    </div>
</section>

<footer>
    <p>&copy; 2025 Albel Computer Graphics and Web Design</p>
</footer>

</body>
</html>


