<?php
require 'connect.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $message = $_POST['message'] ?? '';

    if ($name === '' || $phone === '' || $message === '') {
        $errors[] = 'All fields are required.';
    }

    if (empty($errors)) {
        try {
            $stmt = $mysqli->prepare("INSERT INTO services(name, phone, message) VALUES (?, ?, ?)");
            $stmt->bind_param('sss', $name, $phone, $message);
            $stmt->execute();
            $stmt->close();

            // Redirect after successful insert
            header("Location: index.php");
            exit;
        } catch (Exception $e) {
            error_log("DB Error: " . $e->getMessage());
            $errors[] = 'Could not save your request. Please try again later.';
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Albel Graphics & Web Design | Services</title>
  <style>
    body { font:15px/1.5 Arial,sans-serif; margin:0; padding:0; }
    .container { width:80%; margin:auto; overflow:hidden; }
    header, footer { background:#35424a; color:#fff; }
    header { padding:30px 0; border-bottom:3px solid #e8491d; }
    nav ul { list-style:none; margin:0; padding:0; }
    nav li { display:inline; padding:0 20px; }
    .highlight, .current a { color:#e8491d; font-weight:bold; }
    .button_1 { background:#e8491d; color:#fff; border:none; padding:10px 20px; cursor:pointer; }
    .dark { padding:15px; background:#35424a; color:#fff; margin:20px 0; }
    .errors p { background:#fdd; color:#900; padding:10px; margin:5px 0; }
    .success { background:#dfd; color:#060; padding:10px; margin:5px 0; }
    article#main-col { float:left; width:65%; }
    aside#sidebar { float:right; width:30%; }
    aside#sidebar .quote input,
    aside#sidebar .quote textarea { width:100%; padding:6px; margin-bottom:10px; }
    ul#services li { background:#f4f4f4; border:1px solid #ccc; margin:10px 0; padding:10px; list-style:none; }
    footer { text-align:center; padding:20px 0; background:#e8491d; color:#fff; clear:both; }
    @media(max-width:768px) {
      article#main-col, aside#sidebar { width:100%; float:none; text-align:center; }
    }
  </style>
</head>
<body>

<header>
  <div class="container">
    <div id="branding">
      <h1><span class="highlight">Albel</span> Graphics & Web Design</h1>
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li class="current"><a href="services.php">Services</a></li>
      </ul>
    </nav>
  </div>
</header>

<section id="main">
  <div class="container">
    <article id="main-col">
      <h1 class="page-title">Services</h1>
      <ul id="services">
        <li><h3>Website Design</h3><p>We build beautiful, responsive websites for all sectors.</p></li>
        <li><h3>Website Maintenance</h3><p>We ensure full security and upkeep for your site.</p></li>
         <li><h3>Website Developmemnt</h3><p>We ensure good improvement and developmemnt for your site.</p></li>
        <li><h3>Website Hosting</h3><p>Reliable hosting plans to suit your needs.</p></li>
        <li><h3>Graphic Design</h3><p>Company Logo, Posters, Flyers, Brochures, Bunners, Aids, Stickers, and Photo Editing. As well sa video production.</p></li>
        <li><h3>Database Creation</h3><p>Secure and scalable data storage solutions.</p></li>
        <li><h3>Networking</h3><p>Network setup, troubleshooting, and support.</p></li>
      </ul>
    </article>

    <aside id="sidebar">
      <div class="dark">
        <h3>Request Our Services</h3>

        <?php if (!empty($errors)): ?>
          <div class="errors">
            <?php foreach ($errors as $err): ?>
              <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
          </div>
        <?php elseif ($success): ?>
          <p class="success">Thank you! Your request has been submitted.</p>
        <?php endif; ?>

        <form class="quote" method="POST" action="">
          <label>Name</label>
          <input type="text" name="name" required>
          <label>Phone</label>
          <input type="tel" name="phone" required>
          <label>Message</label>
          <textarea name="message" required></textarea>
          <button class="button_1" type="submit">Send</button>
        </form>
      </div>
    </aside>
  </div>
</section>

<footer>
  <p>&copy; 2025 Albel Computer Graphics and Web Design</p>
</footer>

</body>
</html>


